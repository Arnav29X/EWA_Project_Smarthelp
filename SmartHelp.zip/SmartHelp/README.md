# SmartHelp – Priority-Based IT Support & Ticket Management System

Minor Project: Enterprise Web Applications (CSL273)  
Problem Statement 10: Helpdesk Ticket Management and Worker System

## Requirements
- Java 17 or later
- Apache Maven
- MySQL Server
- VS Code or another Java IDE

## Setup
1. Create a MySQL database named `smarthelp`.
2. Execute the SQL statements in `smarthelp_schema_and_sample_data.sql`.
3. Configure the JDBC URL, username, and password in `DBConnection.java` (or the project's external configuration if you have moved credentials there).
4. Open a terminal in the project root (the folder containing `pom.xml`).
5. Compile:
   ```powershell
   mvn clean compile
   ```
6. Run:
   ```powershell
   mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java "-Dexec.mainClass=com.smarthelp.Main"
   ```
7. Run offline verification tests, if `OfflineTest.java` is present:
   ```powershell
   mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java "-Dexec.mainClass=com.smarthelp.OfflineTest"
   ```

## Features
- User portal: raise and track support tickets.
- Admin portal: view all/pending tickets, process tickets, resolve tickets, generate reports.
- Automatic priority calculation.
- Priority-based concurrent processing with worker threads.
- Engineer assignment by ticket category and active workload.
- JDBC persistence and ticket history.
- Spring Core annotation-based configuration and dependency injection.
- Normal and strict escalation policies.

## Database tables
- users
- engineers
- tickets
- ticket_history

## Important
- Do not commit real database passwords to a public repository.
- The SQL file contains schema and example engineer rows. Review sample rows before executing against an existing database.
- Keep at least two console/database screenshots as execution evidence for submission.