-- SmartHelp database schema
-- Review before execution. CREATE TABLE IF NOT EXISTS preserves existing tables.
CREATE DATABASE IF NOT EXISTS smarthelp;
USE smarthelp;

CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE
);

CREATE TABLE IF NOT EXISTS engineers (
    engineer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS tickets (
    ticket_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    description VARCHAR(500) NOT NULL,
    category VARCHAR(50) NOT NULL,
    priority VARCHAR(20) NOT NULL,
    status VARCHAR(30) DEFAULT 'OPEN',
    engineer_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (engineer_id) REFERENCES engineers(engineer_id)
);

CREATE TABLE IF NOT EXISTS ticket_history (
    history_id INT PRIMARY KEY AUTO_INCREMENT,
    ticket_id INT NOT NULL,
    action VARCHAR(200) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id)
);

-- Sample engineers only. Avoid duplicate insertion if this script is re-run.
INSERT INTO engineers (name, category)
SELECT 'Aman', 'NETWORK'
WHERE NOT EXISTS (SELECT 1 FROM engineers WHERE name='Aman' AND category='NETWORK');

INSERT INTO engineers (name, category)
SELECT 'Rohit', 'SOFTWARE'
WHERE NOT EXISTS (SELECT 1 FROM engineers WHERE name='Rohit' AND category='SOFTWARE');

INSERT INTO engineers (name, category)
SELECT 'Neha', 'HARDWARE'
WHERE NOT EXISTS (SELECT 1 FROM engineers WHERE name='Neha' AND category='HARDWARE');

INSERT INTO engineers (name, category)
SELECT 'Rahul', 'NETWORK'
WHERE NOT EXISTS (SELECT 1 FROM engineers WHERE name='Rahul' AND category='NETWORK');

-- Optional verification queries:
-- SELECT * FROM users;
-- SELECT * FROM engineers;
-- SELECT * FROM tickets;
-- SELECT * FROM ticket_history;
