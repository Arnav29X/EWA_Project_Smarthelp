package com.smarthelp;

import com.smarthelp.config.AppConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.smarthelp.service.TicketService;
import com.smarthelp.service.UserPortal;
import com.smarthelp.service.AdminPortal;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        TicketService ticketService = context.getBean(TicketService.class);

        UserPortal userPortal = new UserPortal(scanner, ticketService);
        AdminPortal adminPortal = new AdminPortal(scanner, ticketService);

        while (true) {

            System.out.println("\n================================");
            System.out.println("   SMARTHELP TICKET SYSTEM");
            System.out.println("================================");
            System.out.println("1. User Portal");
            System.out.println("2. Admin Portal");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = scanner.nextInt();
                scanner.nextLine();
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.println("Invalid input! Please enter a number.");
                continue;
            }

            switch (choice) {

                case 1:
                    userPortal.showMenu();
                    break;

                case 2:
                    adminPortal.showMenu();
                    break;

                case 3:
                    System.out.println("Thank you for using SmartHelp!");
                    scanner.close();
                    context.close();
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}