
package com.smarthelp.service;

import org.springframework.stereotype.Component;

@Component("normalEscalationService")
public class NormalEscalationService implements EscalationService {

    @Override
    public boolean shouldEscalate(String priority) {
        return priority.equalsIgnoreCase("CRITICAL");
    }
}