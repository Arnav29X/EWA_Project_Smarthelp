package com.smarthelp.service;

public class PriorityCalculator {

    public static String calculatePriority(int score) {

        if (score <= 2) {
            return "LOW";
        }
        else if (score <= 4) {
            return "MEDIUM";
        }
        else if (score <= 6) {
            return "HIGH";
        }
        else {
            return "CRITICAL";
        }
    }
}