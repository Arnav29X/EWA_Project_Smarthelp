package com.smarthelp.service;

import com.smarthelp.model.Ticket;
import java.util.Comparator;

public class TicketPriorityComparator implements Comparator<Ticket> {

    private int getPriorityValue(String priority) {

        switch (priority) {
            case "CRITICAL":
                return 1;

            case "HIGH":
                return 2;

            case "MEDIUM":
                return 3;

            case "LOW":
                return 4;

            default:
                return 5;
        }
    }

    @Override
    public int compare(Ticket t1, Ticket t2) {

        int priorityComparison =
                getPriorityValue(t1.getPriority()) -
                getPriorityValue(t2.getPriority());

        if (priorityComparison != 0) {
            return priorityComparison;
        }

        return t1.getTicketId() - t2.getTicketId();
    }
}