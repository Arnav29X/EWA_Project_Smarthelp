package com.smarthelp.service;

import com.smarthelp.model.Ticket;

public class EngineerWorker implements Runnable {

    private int engineerId;
    private String engineerName;
    private Ticket ticket;
    private TicketService ticketService;

    public EngineerWorker(int engineerId, String engineerName,
                          Ticket ticket, TicketService ticketService) {

        this.engineerId = engineerId;
        this.engineerName = engineerName;
        this.ticket = ticket;
        this.ticketService = ticketService;
    }

    @Override
    public void run() {

        System.out.println(
                engineerName + " assigned Ticket #" + ticket.getTicketId()
        );

        System.out.println(
                engineerName + " started working on Ticket #" + ticket.getTicketId()
        );

        ticketService.updateTicketStatus(
        ticket.getTicketId(),
        "IN_PROGRESS"
        );

        try {
            Thread.sleep(2000);

        } catch (InterruptedException e) {
            System.out.println(engineerName + " was interrupted.");
            Thread.currentThread().interrupt();
        }

        System.out.println(
                engineerName + " completed Ticket #" + ticket.getTicketId()
        );
    }
}