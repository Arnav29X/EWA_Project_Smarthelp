package com.smarthelp.service;

import java.util.InputMismatchException;
import java.util.Scanner;

public class UserPortal {

    private final Scanner scanner;
    private final TicketService ticketService;

    public UserPortal(Scanner scanner, TicketService ticketService) {
        this.scanner = scanner;
        this.ticketService = ticketService;
    }

    public void showMenu() {

        while (true) {

            System.out.println("\n================================");
            System.out.println("       SMARTHELP USER PORTAL");
            System.out.println("================================");
            System.out.println("1. Raise a New Ticket");
            System.out.println("2. View/Track My Tickets");
            System.out.println("3. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = scanner.nextInt();
                scanner.nextLine();
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.println("Invalid input! Please enter a number.");
                continue;
            }

            switch (choice) {

    case 1:
        raiseTicket();
        break;

    case 2:
        viewMyTickets();
        break;

    case 3:
        return;

    default:
        System.out.println("Invalid choice!");
}
        }
    }

    private void raiseTicket() {

        System.out.println("\n--- Raise New Ticket ---");

        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        System.out.print("Enter your email: ");
        String email = scanner.nextLine();

        System.out.print("Describe your problem: ");
        String description = scanner.nextLine();

        System.out.println("\nSelect Category:");
        System.out.println("1. NETWORK");
        System.out.println("2. SOFTWARE");
        System.out.println("3. HARDWARE");
        System.out.print("Choice: ");

        int categoryChoice = scanner.nextInt();
        scanner.nextLine();

        String category;

        switch (categoryChoice) {
            case 1:
                category = "NETWORK";
                break;
            case 2:
                category = "SOFTWARE";
                break;
            case 3:
                category = "HARDWARE";
                break;
            default:
                System.out.println("Invalid category!");
                return;
        }

        System.out.println("\nHow many people are affected?");
        System.out.println("1. Only me");
        System.out.println("2. Few people");
        System.out.println("3. Entire department/lab");
        System.out.print("Choice: ");

        int impact = scanner.nextInt();

        System.out.println("\nHow severe is the problem?");
        System.out.println("1. Minor issue");
        System.out.println("2. Important functionality affected");
        System.out.println("3. System completely unavailable");
        System.out.print("Choice: ");

        int severity = scanner.nextInt();

        System.out.println("\nIs a workaround available?");
        System.out.println("1. Yes");
        System.out.println("2. Partially");
        System.out.println("3. No");
        System.out.print("Choice: ");

        int workaroundChoice = scanner.nextInt();
        scanner.nextLine();

        if (impact < 1 || impact > 3 ||
            severity < 1 || severity > 3 ||
            workaroundChoice < 1 || workaroundChoice > 3) {

            System.out.println("Invalid input!");
            return;
        }

        int workaroundScore;

        if (workaroundChoice == 1) {
            workaroundScore = 0;
        }
        else if (workaroundChoice == 2) {
            workaroundScore = 1;
        }
        else {
            workaroundScore = 2;
        }

        int score = impact + severity + workaroundScore;

        String priority = PriorityCalculator.calculatePriority(score);

        // Special critical condition
        if (impact == 3 && severity == 3) {
            priority = "CRITICAL";
        }

        System.out.println("\n--- Priority Assessment ---");
        System.out.println("Impact Score: " + impact);
        System.out.println("Severity Score: " + severity);
        System.out.println("Workaround Score: " + workaroundScore);
        System.out.println("Total Score: " + score);
        System.out.println("Calculated Priority: " + priority);

        ticketService.createTicket(
                name,
                email,
                description,
                category,
                priority
        );
    }

    private void viewMyTickets() {

    System.out.print("\nEnter your email: ");
    String email = scanner.nextLine();

    ticketService.viewTickets(email);
}
}