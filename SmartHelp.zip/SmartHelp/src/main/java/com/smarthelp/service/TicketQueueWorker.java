package com.smarthelp.service;

import com.smarthelp.model.Engineer;
import com.smarthelp.model.Ticket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.PriorityBlockingQueue;

public class TicketQueueWorker implements Runnable {

    private PriorityBlockingQueue<Ticket> ticketQueue;
    private TicketService ticketService;
    private HashMap<String, ArrayList<Engineer>> engineerMap;

    public TicketQueueWorker(
            PriorityBlockingQueue<Ticket> ticketQueue,
            TicketService ticketService,
            HashMap<String, ArrayList<Engineer>> engineerMap) {

        this.ticketQueue = ticketQueue;
        this.ticketService = ticketService;
        this.engineerMap = engineerMap;
    }

    @Override
    public void run() {

        Ticket ticket;

        while ((ticket = ticketQueue.poll()) != null) {

            System.out.println(
                    Thread.currentThread().getName()
                    + " picked Ticket #" + ticket.getTicketId()
            );

            ticketService.processSingleTicket(ticket, engineerMap);
        }
    }
}
