
package com.smarthelp.service;

import org.springframework.stereotype.Component;

@Component("strictEscalationService")
public class StrictEscalationService implements EscalationService {

    @Override
    public boolean shouldEscalate(String priority) {
        return priority.equalsIgnoreCase("HIGH")
                || priority.equalsIgnoreCase("CRITICAL");
    }
}