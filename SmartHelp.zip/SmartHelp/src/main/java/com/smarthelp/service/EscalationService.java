
package com.smarthelp.service;

public interface EscalationService {

    boolean shouldEscalate(String priority);

}