package com.smarthelp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.smarthelp.model.Engineer;
import java.util.PriorityQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;

import com.smarthelp.model.Ticket;
import com.smarthelp.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class TicketService {

    @Autowired
    @Qualifier("normalEscalationService")
    private EscalationService escalationService;

    public int createTicket(String name, String email,
            String description, String category, String priority) {

        Connection connection = null;

        try {
            connection = DBConnection.getConnection();
            connection.setAutoCommit(false);

            int userId = getOrCreateUser(connection, name, email);

            String ticketQuery =
                    "INSERT INTO tickets " +
                    "(user_id, description, category, priority, status) " +
                    "VALUES (?, ?, ?, ?, ?)";

            int ticketId;

            try (PreparedStatement ps = connection.prepareStatement(
                    ticketQuery, PreparedStatement.RETURN_GENERATED_KEYS)) {

                ps.setInt(1, userId);
                ps.setString(2, description);
                ps.setString(3, category);
                ps.setString(4, priority);
                ps.setString(5, "OPEN");

                ps.executeUpdate();

                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        ticketId = rs.getInt(1);
                    } else {
                        throw new SQLException("Ticket ID not generated");
                    }
                }
            }

            // Save ticket creation history
            String historyQuery =
                    "INSERT INTO ticket_history (ticket_id, action) VALUES (?, ?)";

            try (PreparedStatement ps =
                         connection.prepareStatement(historyQuery)) {

                ps.setInt(1, ticketId);
                ps.setString(2, "Ticket created with priority " + priority);
                ps.executeUpdate();
            }

            // Automatic escalation using Spring DI
            if (escalationService.shouldEscalate(priority)) {

                String escalationQuery =
                        "INSERT INTO ticket_history (ticket_id, action) VALUES (?, ?)";

                try (PreparedStatement ps =
                             connection.prepareStatement(escalationQuery)) {

                    ps.setInt(1, ticketId);
                    ps.setString(2,
                            "Ticket automatically escalated due to "
                                    + priority + " priority");

                    ps.executeUpdate();
                }
            }

            connection.commit();

            System.out.println("\nTicket created successfully!");
            System.out.println("Ticket ID: " + ticketId);
            System.out.println("Priority: " + priority);
            System.out.println("Status: OPEN");

            return ticketId;

        } catch (SQLException e) {

            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException rollbackError) {
                rollbackError.printStackTrace();
            }

            System.out.println("Ticket creation failed!");
            e.printStackTrace();

            return -1;

        } finally {

            try {
                if (connection != null) {
                    connection.setAutoCommit(true);
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private int getOrCreateUser(Connection connection,
                               String name, String email)
                               throws SQLException {

        String searchQuery =
                "SELECT user_id FROM users WHERE email = ?";

        try (PreparedStatement ps =
                     connection.prepareStatement(searchQuery)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("user_id");
                }
            }
        }

        String insertQuery =
                "INSERT INTO users (name, email) VALUES (?, ?)";

        try (PreparedStatement ps =
                     connection.prepareStatement(
                             insertQuery,
                             PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, name);
            ps.setString(2, email);

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        throw new SQLException("User ID could not be generated");
    }

    public void viewTickets(String email) {

        String query =
                "SELECT t.ticket_id, t.description, t.category, " +
                "t.priority, t.status, t.created_at " +
                "FROM tickets t " +
                "JOIN users u ON t.user_id = u.user_id " +
                "WHERE u.email = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {

                boolean found = false;

                System.out.println("\n================================");
                System.out.println("       MY SUPPORT TICKETS");
                System.out.println("================================");

                while (rs.next()) {

                    found = true;

                    System.out.println("\nTicket ID: " +
                            rs.getInt("ticket_id"));

                    System.out.println("Problem: " +
                            rs.getString("description"));

                    System.out.println("Category: " +
                            rs.getString("category"));

                    System.out.println("Priority: " +
                            rs.getString("priority"));

                    System.out.println("Status: " +
                            rs.getString("status"));

                    System.out.println("Created At: " +
                            rs.getTimestamp("created_at"));

                    System.out.println("--------------------------------");
                }

                if (!found) {
                    System.out.println("No tickets found for this email.");
                }
            }

        } catch (SQLException e) {

            System.out.println("Unable to retrieve tickets!");
            e.printStackTrace();
        }
    }

    public void viewAllTickets() {

        String query =
                "SELECT t.ticket_id, u.name, t.description, " +
                "t.category, t.priority, t.status, " +
                "t.engineer_id, t.created_at " +
                "FROM tickets t " +
                "JOIN users u ON t.user_id = u.user_id " +
                "ORDER BY t.ticket_id";

        displayTickets(query);
    }

    public void viewPendingTickets() {

        String query =
                "SELECT t.ticket_id, u.name, t.description, " +
                "t.category, t.priority, t.status, " +
                "t.engineer_id, t.created_at " +
                "FROM tickets t " +
                "JOIN users u ON t.user_id = u.user_id " +
                "WHERE t.status != 'RESOLVED' " +
                "ORDER BY t.ticket_id";

        displayTickets(query);
    }

    private void displayTickets(String query) {

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println("\n================================");
                System.out.println("Ticket ID: " +
                        rs.getInt("ticket_id"));

                System.out.println("User: " +
                        rs.getString("name"));

                System.out.println("Problem: " +
                        rs.getString("description"));

                System.out.println("Category: " +
                        rs.getString("category"));

                System.out.println("Priority: " +
                        rs.getString("priority"));

                System.out.println("Status: " +
                        rs.getString("status"));

                System.out.println("Engineer ID: " +
                        rs.getString("engineer_id"));

                System.out.println("Created At: " +
                        rs.getTimestamp("created_at"));

                System.out.println("================================");
            }

            if (!found) {
                System.out.println("No tickets found.");
            }

        } catch (SQLException e) {

            System.out.println("Unable to retrieve tickets!");
            e.printStackTrace();
        }
    }

    public void resolveTicket(int ticketId) {

        Connection connection = null;

        try {
            connection = DBConnection.getConnection();
            connection.setAutoCommit(false);

            // Check current status before resolving
            String checkQuery =
                    "SELECT status FROM tickets WHERE ticket_id = ?";

            String currentStatus = null;
            try (PreparedStatement checkPs =
                         connection.prepareStatement(checkQuery)) {
                checkPs.setInt(1, ticketId);
                try (ResultSet rs = checkPs.executeQuery()) {
                    if (rs.next()) {
                        currentStatus = rs.getString("status");
                    }
                }
            }

            if (currentStatus == null) {
                connection.rollback();
                System.out.println("Ticket ID not found!");
                return;
            }

            if ("RESOLVED".equals(currentStatus)) {
                connection.rollback();
                System.out.println("Ticket #" + ticketId
                        + " is already resolved.");
                return;
            }

            if ("OPEN".equals(currentStatus)) {
                connection.rollback();
                System.out.println("Ticket #" + ticketId
                        + " is still OPEN and has not been assigned yet.");
                return;
            }

            String query =
                    "UPDATE tickets SET status = 'RESOLVED', " +
                    "resolved_at = CURRENT_TIMESTAMP " +
                    "WHERE ticket_id = ?";

            int rowsUpdated;

            try (PreparedStatement ps =
                         connection.prepareStatement(query)) {

                ps.setInt(1, ticketId);
                rowsUpdated = ps.executeUpdate();
            }

            if (rowsUpdated > 0) {

                String historyQuery =
                        "INSERT INTO ticket_history (ticket_id, action) " +
                        "VALUES (?, ?)";

                try (PreparedStatement historyPs =
                             connection.prepareStatement(historyQuery)) {

                    historyPs.setInt(1, ticketId);
                    historyPs.setString(2, "Ticket resolved by Admin");
                    historyPs.executeUpdate();
                }

                connection.commit();

                System.out.println("Ticket #" + ticketId
                        + " resolved successfully!");

            } else {

                connection.rollback();
                System.out.println("Ticket ID not found!");
            }

        } catch (SQLException e) {

            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException rollbackError) {
                rollbackError.printStackTrace();
            }

            System.out.println("Unable to resolve ticket!");
            e.printStackTrace();

        } finally {

            try {
                if (connection != null) {
                    connection.setAutoCommit(true);
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void generateReports() {

        String query =
                "SELECT priority, COUNT(*) AS total " +
                "FROM tickets GROUP BY priority";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            System.out.println("\n===== TICKETS BY PRIORITY =====");

            while (rs.next()) {
                String priority = rs.getString("priority");
                int total = rs.getInt("total");

                System.out.println(priority + ": " + total);
            }

        } catch (SQLException e) {
            System.out.println("Error generating report: " + e.getMessage());
        }

        String statusQuery =
                "SELECT status, COUNT(*) AS total " +
                "FROM tickets GROUP BY status";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(statusQuery);
             ResultSet rs = pstmt.executeQuery()) {

            System.out.println("\n===== TICKETS BY STATUS =====");

            while (rs.next()) {
                String status = rs.getString("status");
                int total = rs.getInt("total");

                System.out.println(status + ": " + total);
            }

        } catch (SQLException e) {
            System.out.println("Error generating status report: "
                    + e.getMessage());
        }

        String categoryQuery =
                "SELECT category, COUNT(*) AS total " +
                "FROM tickets GROUP BY category";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(categoryQuery);
             ResultSet rs = pstmt.executeQuery()) {

            System.out.println("\n===== TICKETS BY CATEGORY =====");

            while (rs.next()) {
                String category = rs.getString("category");
                int total = rs.getInt("total");

                System.out.println(category + ": " + total);
            }

        } catch (SQLException e) {
            System.out.println("Error generating category report: "
                    + e.getMessage());
        }
    }

    /**
     * Assigns a ticket to an engineer in the database.
     * Returns true if the assignment succeeded, false otherwise.
     */
    public boolean assignTicketToEngineer(int ticketId, int engineerId) {

        String updateQuery =
                "UPDATE tickets SET engineer_id = ?, status = 'ASSIGNED' " +
                "WHERE ticket_id = ? AND status = 'OPEN'";

        String historyQuery =
                "INSERT INTO ticket_history (ticket_id, action) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection()) {

            conn.setAutoCommit(false);

            try (PreparedStatement updateStmt =
                         conn.prepareStatement(updateQuery);
                 PreparedStatement historyStmt =
                         conn.prepareStatement(historyQuery)) {

                updateStmt.setInt(1, engineerId);
                updateStmt.setInt(2, ticketId);

                int rowsUpdated = updateStmt.executeUpdate();

                if (rowsUpdated > 0) {

                    historyStmt.setInt(1, ticketId);
                    historyStmt.setString(
                            2,
                            "Ticket assigned to Engineer ID: " + engineerId
                    );

                    historyStmt.executeUpdate();

                    conn.commit();

                    System.out.println(
                            "Ticket #" + ticketId + " assigned successfully!"
                    );

                    return true;

                } else {
                    conn.rollback();

                    System.out.println(
                            "Ticket #" + ticketId +
                            " is not OPEN or does not exist."
                    );

                    return false;
                }

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }

        } catch (SQLException e) {
            System.out.println("Error assigning ticket: " + e.getMessage());
            return false;
        }
    }

    public HashMap<String, ArrayList<Engineer>> loadEngineersByCategory() {

        HashMap<String, ArrayList<Engineer>> engineerMap = new HashMap<>();

        String query = "SELECT * FROM engineers";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {

                Engineer engineer = new Engineer(
                        rs.getInt("engineer_id"),
                        rs.getString("name"),
                        rs.getString("category")
                );

                engineerMap
                        .computeIfAbsent(engineer.getCategory(),
                                k -> new ArrayList<>())
                        .add(engineer);
            }

        } catch (SQLException e) {
            System.out.println("Error loading engineers: " + e.getMessage());
        }

        return engineerMap;
    }

    public synchronized Engineer findEngineerForTicket(
            Ticket ticket,
            HashMap<String, ArrayList<Engineer>> engineerMap) {

        ArrayList<Engineer> engineers =
                engineerMap.get(ticket.getCategory());

        if (engineers == null || engineers.isEmpty()) {
            System.out.println("No engineer available for category: "
                    + ticket.getCategory());
            return null;
        }

        Engineer selectedEngineer = null;
        int minimumWorkload = Integer.MAX_VALUE;

        for (Engineer engineer : engineers) {

            int workload = getActiveTicketCount(engineer.getEngineerId());

            if (workload < minimumWorkload) {
                minimumWorkload = workload;
                selectedEngineer = engineer;
            }
        }

        if (selectedEngineer != null) {
            System.out.println(
                    "Selected Engineer: " + selectedEngineer.getName()
                    + " | Active Tickets: " + minimumWorkload
            );
        }

        return selectedEngineer;
    }

    private int getActiveTicketCount(int engineerId) {

        String query = "SELECT COUNT(*) FROM tickets " +
                       "WHERE engineer_id = ? " +
                       "AND status IN ('ASSIGNED', 'IN_PROGRESS')";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, engineerId);

            try (ResultSet rs = pstmt.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (SQLException e) {
            System.out.println("Error checking engineer workload: "
                    + e.getMessage());
        }

        return Integer.MAX_VALUE;
    }

    public PriorityQueue<Ticket> loadOpenTickets() {

        PriorityQueue<Ticket> ticketQueue =
                new PriorityQueue<>(new TicketPriorityComparator());

        String query = "SELECT * FROM tickets WHERE status = 'OPEN'";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {

                Ticket ticket = new Ticket(
                        rs.getInt("ticket_id"),
                        rs.getInt("user_id"),
                        null,
                        rs.getString("description"),
                        rs.getString("category"),
                        rs.getString("priority"),
                        rs.getString("status"),
                        rs.getInt("engineer_id")
                );

                ticketQueue.add(ticket);
            }

            System.out.println("Total OPEN tickets loaded: "
                    + ticketQueue.size());

        } catch (SQLException e) {
            System.out.println("Error loading tickets: " + e.getMessage());
        }

        return ticketQueue;
    }

    public void processOpenTickets() {

        // Load all OPEN tickets
        PriorityQueue<Ticket> openTickets = loadOpenTickets();

        if (openTickets.isEmpty()) {
            System.out.println("No open tickets available!");
            return;
        }

        // Load engineer map once for all workers to share
        HashMap<String, ArrayList<Engineer>> engineerMap =
                loadEngineersByCategory();

        // Create a thread-safe priority queue
        PriorityBlockingQueue<Ticket> ticketQueue =
                new PriorityBlockingQueue<>(11, new TicketPriorityComparator());

        ticketQueue.addAll(openTickets);

        // Create 3 worker threads
        ArrayList<Thread> workers = new ArrayList<>();

        System.out.println("\n===== AUTOMATIC TICKET PROCESSING =====");

        for (int i = 1; i <= 3; i++) {

            Thread worker = new Thread(
                    new TicketQueueWorker(ticketQueue, this, engineerMap),
                    "Support-Worker-" + i
            );

            workers.add(worker);
            worker.start();
        }

        // Wait for all workers to finish
        for (Thread worker : workers) {
            try {
                worker.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Processing interrupted!");
                return;
            }
        }

        System.out.println("\n===== TICKET PROCESSING COMPLETED =====");
    }

    public void updateTicketStatus(int ticketId, String status) {

        String updateQuery =
                "UPDATE tickets SET status = ? WHERE ticket_id = ?";

        String historyQuery =
                "INSERT INTO ticket_history (ticket_id, action) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection()) {

            conn.setAutoCommit(false);

            try (PreparedStatement updateStmt =
                         conn.prepareStatement(updateQuery);
                 PreparedStatement historyStmt =
                         conn.prepareStatement(historyQuery)) {

                updateStmt.setString(1, status);
                updateStmt.setInt(2, ticketId);
                updateStmt.executeUpdate();

                historyStmt.setInt(1, ticketId);
                historyStmt.setString(2, "Ticket status changed to " + status);
                historyStmt.executeUpdate();

                conn.commit();

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }

        } catch (SQLException e) {
            System.out.println("Error updating ticket status: "
                    + e.getMessage());
        }
    }

    public synchronized Engineer selectAndAssignEngineer(
            Ticket ticket,
            HashMap<String, ArrayList<Engineer>> engineerMap) {

        Engineer engineer = findEngineerForTicket(ticket, engineerMap);

        if (engineer == null) {
            return null;
        }

        boolean assigned = assignTicketToEngineer(
                ticket.getTicketId(),
                engineer.getEngineerId()
        );

        if (!assigned) {
            System.out.println("Ticket #" + ticket.getTicketId()
                    + " was already assigned by another worker.");
            return null;
        }

        return engineer;
    }

    public void processSingleTicket(Ticket ticket,
            HashMap<String, ArrayList<Engineer>> engineerMap) {

        Engineer engineer = selectAndAssignEngineer(ticket, engineerMap);

        if (engineer == null) {
            System.out.println(
                    "No engineer available for Ticket #"
                    + ticket.getTicketId()
            );
            return;
        }

        System.out.println(
                engineer.getName() + " started Ticket #"
                + ticket.getTicketId()
        );

        updateTicketStatus(ticket.getTicketId(), "IN_PROGRESS");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Ticket processing interrupted.");
            return;
        }

        System.out.println(
                engineer.getName() + " finished Ticket #"
                + ticket.getTicketId()
        );
    }
}
