package com.smarthelp.service;

import java.util.InputMismatchException;
import java.util.Scanner;

public class AdminPortal {

    private final Scanner scanner;
    private final TicketService ticketService;

    public AdminPortal(Scanner scanner, TicketService ticketService) {
        this.scanner = scanner;
        this.ticketService = ticketService;
    }

    public void showMenu() {

        while (true) {

            System.out.println("\n================================");
            System.out.println("       SMARTHELP ADMIN PORTAL");
            System.out.println("================================");
            System.out.println("1. View All Tickets");
            System.out.println("2. View Pending Tickets");
            System.out.println("3. Start Ticket Processing");
            System.out.println("4. Resolve a Ticket");
            System.out.println("5. Generate Reports");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = scanner.nextInt();
                scanner.nextLine();
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.println("Invalid input! Please enter a number.");
                continue;
            }

            switch (choice) {

                case 1:
                    ticketService.viewAllTickets();
                    break;

                case 2:
                    ticketService.viewPendingTickets();
                    break;

                case 3:
                    ticketService.processOpenTickets();
                    break;

                case 4:
                    resolveTicket();
                    break;

                case 5:
                    ticketService.generateReports();
                    break;

                case 6:
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private void resolveTicket() {

        System.out.print("Enter Ticket ID to resolve: ");

        int ticketId;
        try {
            ticketId = scanner.nextInt();
            scanner.nextLine();
        } catch (java.util.InputMismatchException e) {
            scanner.nextLine();
            System.out.println("Invalid input! Please enter a valid ticket ID.");
            return;
        }

        ticketService.resolveTicket(ticketId);
    }
}