package com.smarthelp;

import com.smarthelp.model.Ticket;
import com.smarthelp.service.*;

import java.util.PriorityQueue;
import java.util.concurrent.PriorityBlockingQueue;

/**
 * Offline verification test — tests all logic that does NOT require
 * a database connection.
 */
public class OfflineTest {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {

        System.out.println("===== SmartHelp Offline Verification Tests =====\n");

        // ---- A. Priority Calculation ----
        testPriority("LOW (score 1)", 1, "LOW");
        testPriority("LOW (score 2)", 2, "LOW");
        testPriority("MEDIUM (score 3)", 3, "MEDIUM");
        testPriority("MEDIUM (score 4)", 4, "MEDIUM");
        testPriority("HIGH (score 5)", 5, "HIGH");
        testPriority("HIGH (score 6)", 6, "HIGH");
        testPriority("CRITICAL (score 7)", 7, "CRITICAL");
        testPriority("CRITICAL (score 8)", 8, "CRITICAL");

        // ---- B. Escalation - Normal Mode ----
        NormalEscalationService normalService = new NormalEscalationService();
        testEscalation("Normal: CRITICAL escalates", normalService, "CRITICAL", true);
        testEscalation("Normal: HIGH does NOT escalate", normalService, "HIGH", false);
        testEscalation("Normal: MEDIUM does NOT escalate", normalService, "MEDIUM", false);
        testEscalation("Normal: LOW does NOT escalate", normalService, "LOW", false);

        // ---- C. Escalation - Strict Mode ----
        StrictEscalationService strictService = new StrictEscalationService();
        testEscalation("Strict: CRITICAL escalates", strictService, "CRITICAL", true);
        testEscalation("Strict: HIGH escalates", strictService, "HIGH", true);
        testEscalation("Strict: MEDIUM does NOT escalate", strictService, "MEDIUM", false);
        testEscalation("Strict: LOW does NOT escalate", strictService, "LOW", false);

        // ---- D. Priority Queue Ordering ----
        testPriorityQueueOrdering();

        // ---- E. PriorityBlockingQueue Thread Safety ----
        testPriorityBlockingQueueThreadSafety();

        // ---- F. TicketPriorityComparator ----
        testComparator();

        // ---- G. Ticket Model ----
        testTicketModel();

        // ---- Summary ----
        System.out.println("\n===== RESULTS =====");
        System.out.println("Passed: " + passed);
        System.out.println("Failed: " + failed);
        System.out.println("Total:  " + (passed + failed));
        System.out.println(failed == 0 ? "ALL TESTS PASSED!" : "SOME TESTS FAILED!");
    }

    // ---- Helper methods ----

    private static void testPriority(String label, int score, String expected) {
        String result = PriorityCalculator.calculatePriority(score);
        check(label, expected, result);
    }

    private static void testEscalation(String label,
            EscalationService service, String priority, boolean expected) {
        boolean result = service.shouldEscalate(priority);
        check(label, String.valueOf(expected), String.valueOf(result));
    }

    private static void testPriorityQueueOrdering() {
        System.out.println("\n--- Priority Queue Ordering ---");

        PriorityQueue<Ticket> queue =
                new PriorityQueue<>(new TicketPriorityComparator());

        queue.add(new Ticket(4, 1, "U", "d", "NET", "LOW", "OPEN", 0));
        queue.add(new Ticket(1, 1, "U", "d", "NET", "CRITICAL", "OPEN", 0));
        queue.add(new Ticket(3, 1, "U", "d", "NET", "HIGH", "OPEN", 0));
        queue.add(new Ticket(2, 1, "U", "d", "NET", "MEDIUM", "OPEN", 0));

        String[] expectedOrder = {"CRITICAL", "HIGH", "MEDIUM", "LOW"};
        int i = 0;
        boolean allCorrect = true;

        while (!queue.isEmpty()) {
            Ticket t = queue.poll();
            if (!t.getPriority().equals(expectedOrder[i])) {
                allCorrect = false;
                System.out.println("  FAIL: Expected " + expectedOrder[i]
                        + " but got " + t.getPriority());
            }
            i++;
        }

        if (allCorrect) {
            System.out.println("  PASS: Queue ordering correct (CRITICAL > HIGH > MEDIUM > LOW)");
            passed++;
        } else {
            failed++;
        }
    }

    private static void testPriorityBlockingQueueThreadSafety() {
        System.out.println("\n--- PriorityBlockingQueue Thread Safety ---");

        PriorityBlockingQueue<Ticket> queue =
                new PriorityBlockingQueue<>(11, new TicketPriorityComparator());

        // Add 10 tickets
        for (int i = 1; i <= 10; i++) {
            String prio = i <= 3 ? "CRITICAL" : i <= 5 ? "HIGH" : i <= 8 ? "MEDIUM" : "LOW";
            queue.add(new Ticket(i, 1, "U", "desc", "NET", prio, "OPEN", 0));
        }

        // 3 threads concurrently poll from queue
        java.util.concurrent.atomic.AtomicInteger totalPolled =
                new java.util.concurrent.atomic.AtomicInteger(0);

        java.util.Set<Integer> polledIds =
                java.util.Collections.synchronizedSet(new java.util.HashSet<>());

        Thread[] threads = new Thread[3];
        for (int i = 0; i < 3; i++) {
            threads[i] = new Thread(() -> {
                Ticket t;
                while ((t = queue.poll()) != null) {
                    totalPolled.incrementAndGet();
                    polledIds.add(t.getTicketId());
                }
            }, "TestWorker-" + (i + 1));
            threads[i].start();
        }

        for (Thread t : threads) {
            try { t.join(); } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        boolean nodup = polledIds.size() == 10 && totalPolled.get() == 10;
        if (nodup) {
            System.out.println("  PASS: 3 threads polled 10 tickets with no duplicates");
            passed++;
        } else {
            System.out.println("  FAIL: Expected 10 unique tickets, got "
                    + polledIds.size() + " unique, " + totalPolled.get() + " total");
            failed++;
        }
    }

    private static void testComparator() {
        System.out.println("\n--- Comparator Tie-Breaking ---");

        Ticket t1 = new Ticket(10, 1, "U", "d", "NET", "HIGH", "OPEN", 0);
        Ticket t2 = new Ticket(5, 1, "U", "d", "NET", "HIGH", "OPEN", 0);

        TicketPriorityComparator cmp = new TicketPriorityComparator();
        int result = cmp.compare(t1, t2);

        if (result > 0) {
            System.out.println("  PASS: Same priority, lower ticket ID comes first");
            passed++;
        } else {
            System.out.println("  FAIL: Expected t2 (ID 5) before t1 (ID 10)");
            failed++;
        }
    }

    private static void testTicketModel() {
        System.out.println("\n--- Ticket Model ---");

        Ticket t = new Ticket(42, 7, "Alice", "Broken printer",
                "HARDWARE", "HIGH", "OPEN", 0);

        boolean ok = t.getTicketId() == 42
                && t.getUserId() == 7
                && "Alice".equals(t.getUserName())
                && "Broken printer".equals(t.getDescription())
                && "HARDWARE".equals(t.getCategory())
                && "HIGH".equals(t.getPriority())
                && "OPEN".equals(t.getStatus())
                && t.getEngineerId() == 0;

        t.setStatus("ASSIGNED");
        t.setEngineerId(3);
        ok = ok && "ASSIGNED".equals(t.getStatus())
                && t.getEngineerId() == 3;

        if (ok) {
            System.out.println("  PASS: Ticket model getters/setters work correctly");
            passed++;
        } else {
            System.out.println("  FAIL: Ticket model issue");
            failed++;
        }
    }

    private static void check(String label, String expected, String actual) {
        if (expected.equals(actual)) {
            System.out.println("  PASS: " + label);
            passed++;
        } else {
            System.out.println("  FAIL: " + label
                    + " (expected=" + expected + ", actual=" + actual + ")");
            failed++;
        }
    }
}
