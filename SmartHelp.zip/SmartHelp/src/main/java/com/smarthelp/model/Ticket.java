package com.smarthelp.model;

public class Ticket {

    private int ticketId;
    private int userId;
    private String userName;
    private String description;
    private String category;
    private String priority;
    private String status;
    private int engineerId;

    public Ticket(int ticketId, int userId, String userName,
                  String description, String category,
                  String priority, String status, int engineerId) {

        this.ticketId = ticketId;
        this.userId = userId;
        this.userName = userName;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.status = status;
        this.engineerId = engineerId;
    }

    public int getTicketId() {
        return ticketId;
    }

    public int getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public String getDescription() {
        return description;
    }

    public String getCategory() {
        return category;
    }

    public String getPriority() {
        return priority;
    }

    public String getStatus() {
        return status;
    }

    public int getEngineerId() {
        return engineerId;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setEngineerId(int engineerId) {
        this.engineerId = engineerId;
    }
}