package com.smarthelp.model;

public class Engineer {

    private int engineerId;
    private String name;
    private String category;

    public Engineer(int engineerId, String name, String category) {
        this.engineerId = engineerId;
        this.name = name;
        this.category = category;
    }

    public int getEngineerId() {
        return engineerId;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }
}